"""Evaluador seguro de funciones f(x) escritas por el usuario, sin usar eval().
Convierte el texto en un árbol sintáctico (AST), acepta solo operaciones, constantes y
funciones de una lista blanca y lo evalúa de forma recursiva con números float.
Elaborado por: [Integrantes del grupo: completar nombres].
"""
import ast
import math
import operator


class ErrorNumerico(Exception):
    """Error de validación del módulo de métodos numéricos; su mensaje es para el usuario."""


class FuncionSegura:
    """Una expresión en x ya validada: se llama como f(x) y devuelve un float finito."""

    LARGO_MAXIMO = 200
    NODOS_MAXIMOS = 120
    CONSTANTES = {"pi": math.pi, "e": math.e}
    FUNCIONES = {
        "sin": math.sin, "sen": math.sin, "cos": math.cos, "tan": math.tan,
        "asin": math.asin, "acos": math.acos, "atan": math.atan,
        "sinh": math.sinh, "cosh": math.cosh, "tanh": math.tanh,
        "exp": math.exp, "log": math.log, "ln": math.log, "log10": math.log10,
        "log2": math.log2, "sqrt": math.sqrt, "cbrt": math.cbrt, "abs": abs,
    }
    OPERADORES = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul}

    def __init__(self, expresion, variable="x"):
        """Valida la expresión; lanza ErrorNumerico con un mensaje claro si no es aceptable."""
        self.expresion = expresion.strip()
        self.variable = variable
        self._arbol = self._analizar()

    def _analizar(self):
        """Convierte el texto en AST y comprueba que solo use elementos autorizados."""
        if not self.expresion:
            raise ErrorNumerico("Escriba una función, por ejemplo: x**3 - 2*x - 5")
        if len(self.expresion) > self.LARGO_MAXIMO:
            raise ErrorNumerico(f"La función es demasiado larga (máximo {self.LARGO_MAXIMO} caracteres)")
        if "^" in self.expresion:
            raise ErrorNumerico("El símbolo ^ no es potencia en Python: use ** (por ejemplo x**2)")
        try:
            arbol = ast.parse(self.expresion.replace(",", "."), mode="eval")
        except SyntaxError:
            raise ErrorNumerico(f"No se entiende la función «{self.expresion}». Revise paréntesis y "
                                "operadores (escriba 2*x, no 2x)") from None
        if sum(1 for _ in ast.walk(arbol)) > self.NODOS_MAXIMOS:
            raise ErrorNumerico("La función es demasiado compleja")
        self._validar(arbol.body)
        return arbol.body

    def _validar(self, nodo):
        """Recorre el árbol y rechaza cualquier elemento fuera de la lista blanca."""
        if isinstance(nodo, ast.BinOp) and isinstance(nodo.op, (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow)):
            self._validar(nodo.left)
            self._validar(nodo.right)
        elif isinstance(nodo, ast.UnaryOp) and isinstance(nodo.op, (ast.UAdd, ast.USub)):
            self._validar(nodo.operand)
        elif isinstance(nodo, ast.Constant) and type(nodo.value) in (int, float):
            return
        elif isinstance(nodo, ast.Name):
            self._validar_nombre(nodo.id)
        elif isinstance(nodo, ast.Call):
            self._validar_llamada(nodo)
        else:
            raise ErrorNumerico("La función contiene un elemento no permitido; use solo números, "
                                f"{self.variable or 'x'}, + - * / **, paréntesis y funciones como sin, cos, exp, log, sqrt")

    def _validar_nombre(self, nombre):
        """Solo se aceptan la variable y las constantes autorizadas."""
        if nombre != self.variable and nombre not in self.CONSTANTES:
            permitidas = f"{self.variable}, pi o e" if self.variable else "pi o e"
            raise ErrorNumerico(f"«{nombre}» no es una variable ni una constante permitida (use {permitidas})")

    def _validar_llamada(self, nodo):
        """Solo se aceptan funciones de la lista blanca, con argumentos posicionales."""
        if not isinstance(nodo.func, ast.Name) or nodo.func.id not in self.FUNCIONES or nodo.keywords:
            nombre = getattr(nodo.func, "id", "esa llamada")
            raise ErrorNumerico(f"La función «{nombre}» no está permitida. Permitidas: "
                                + ", ".join(sorted(self.FUNCIONES)))
        if not 1 <= len(nodo.args) <= 2:
            raise ErrorNumerico(f"«{nodo.func.id}» recibe uno o dos argumentos")
        for argumento in nodo.args:
            self._validar(argumento)

    def __call__(self, x):
        """Evalúa f(x); si no está definida o no es finita lanza ErrorNumerico explicando el motivo."""
        try:
            valor = self._evaluar(self._arbol, float(x))
        except ZeroDivisionError:
            raise ErrorNumerico(f"f no está definida en x = {x:.10g}: división entre cero") from None
        except OverflowError:
            raise ErrorNumerico(f"f(x) desborda (overflow) en x = {x:.10g}") from None
        except ValueError:
            raise ErrorNumerico(f"f no está definida en x = {x:.10g}: valor fuera del dominio "
                                "(raíz o logaritmo de un negativo, etc.)") from None
        if not math.isfinite(valor):
            raise ErrorNumerico(f"f(x) no es un número finito en x = {x:.10g}")
        return valor

    def _evaluar(self, nodo, x):
        """Evaluación recursiva de un nodo ya validado."""
        if isinstance(nodo, ast.Constant):
            return float(nodo.value)
        if isinstance(nodo, ast.Name):
            return x if nodo.id == self.variable else self.CONSTANTES[nodo.id]
        if isinstance(nodo, ast.UnaryOp):
            valor = self._evaluar(nodo.operand, x)
            return -valor if isinstance(nodo.op, ast.USub) else valor
        if isinstance(nodo, ast.BinOp):
            return self._operar(nodo, x)
        argumentos = [self._evaluar(arg, x) for arg in nodo.args]
        return float(self.FUNCIONES[nodo.func.id](*argumentos))

    def _operar(self, nodo, x):
        """Operación binaria con floats; la potencia usa math.pow para no crear enteros enormes."""
        izquierda, derecha = self._evaluar(nodo.left, x), self._evaluar(nodo.right, x)
        if isinstance(nodo.op, ast.Div):
            return izquierda / derecha
        if isinstance(nodo.op, ast.Pow):
            return math.pow(izquierda, derecha)
        return self.OPERADORES[type(nodo.op)](izquierda, derecha)


def leer_numero(texto, nombre):
    """Convierte un texto como '1e-4', '0,5', '1/3' o '2*pi' en float; ErrorNumerico si no sirve."""
    try:
        valor = FuncionSegura(str(texto), variable=None)(0.0)
    except ErrorNumerico as error:
        raise ErrorNumerico(f"{nombre} no es un número válido ({error})") from None
    return valor


def formato(valor, cifras=10):
    """Texto corto de un float para tablas y mensajes; maneja inf y nan sin romper JSON."""
    if isinstance(valor, str) or valor is None:
        return valor
    if not math.isfinite(valor):
        return "inf" if valor > 0 else ("-inf" if valor < 0 else "nan")
    return f"{valor:.{cifras}g}"
