"""Programa 8: métodos iterativos de Jacobi y Gauss-Seidel para resolver Ax = b.
Valida los datos, analiza la diagonal (ceros, dominancia, reordenamiento) e itera hasta la tolerancia.
Los cálculos iterativos usan float; la solución de referencia sale del Gauss-Jordan de la calculadora.
Elaborado por: [Integrantes del grupo: completar nombres].
"""
import math
from dataclasses import dataclass, field
from itertools import permutations

from .evaluador_seguro import ErrorNumerico
from .sesion_02_07_08_sistemas import SistemaLineal

MAX_ORDEN = 8
LIMITE_DIVERGENCIA = 1e12


@dataclass
class SistemaIterativo:
    """Datos ya validados: A (n × n), b, x⁽⁰⁾, tolerancia ε y máximo de iteraciones."""
    a: list
    b: list
    x0: list
    tolerancia: float
    maximo: int

    @classmethod
    def validar(cls, a, b, x0, tolerancia, maximo):
        """Comprueba dimensiones, valores finitos, ε > 0 y máximo entero ≥ 1; devuelve el sistema en float."""
        n = len(a)
        if n == 0 or any(len(fila) != n for fila in a):
            raise ErrorNumerico("A debe ser una matriz cuadrada n × n")
        if n > MAX_ORDEN:
            raise ErrorNumerico(f"Esta calculadora admite sistemas de hasta {MAX_ORDEN} × {MAX_ORDEN}")
        for nombre, vector in (("b", b), ("x⁽⁰⁾", x0)):
            if len(vector) != n:
                raise ErrorNumerico(f"{nombre} debe tener {n} componentes (tiene {len(vector)})")
        matriz = [[float(v) for v in fila] for fila in a]
        vector_b, vector_x = [float(v) for v in b], [float(v) for v in x0]
        if not all(math.isfinite(v) for v in [v for fila in matriz for v in fila] + vector_b + vector_x):
            raise ErrorNumerico("Todos los datos deben ser números finitos")
        cls.validar_parada(tolerancia, maximo)
        return cls(matriz, vector_b, vector_x, float(tolerancia), int(maximo))

    @staticmethod
    def validar_parada(tolerancia, maximo):
        """ε debe ser positiva y finita; el máximo, un entero positivo."""
        if not math.isfinite(tolerancia) or tolerancia <= 0:
            raise ErrorNumerico("La tolerancia ε debe ser un número decimal positivo (por ejemplo 1e-6)")
        if int(maximo) != maximo or maximo < 1:
            raise ErrorNumerico("El máximo de iteraciones debe ser un entero positivo")

    def residuo(self, x):
        """‖Ax − b‖∞; es inf si x tiene valores no finitos."""
        if not all(math.isfinite(v) for v in x):
            return math.inf
        return max(abs(sum(f * v for f, v in zip(fila, x)) - bi) for fila, bi in zip(self.a, self.b))


@dataclass
class FilaDominancia:
    """Una fila de A: |a_ii|, suma de |a_ij| con j ≠ i y si |a_ii| > suma."""
    fila: int
    diagonal: float
    resto: float

    @property
    def estricta(self):
        """True si |a_ii| > suma del resto de la fila."""
        return self.diagonal > self.resto


@dataclass
class Reordenamiento:
    """permutacion[j] = fila original que pasa a la posición j; con su calidad de dominancia."""
    permutacion: list
    dominante: bool
    cambia: bool


class AnalisisDiagonal:
    """Ceros en la diagonal, dominancia estricta por filas y búsqueda de un reordenamiento."""

    @staticmethod
    def ceros(a):
        """Posiciones (desde 1) donde a_ii = 0."""
        return [i + 1 for i in range(len(a)) if a[i][i] == 0]

    @staticmethod
    def filas(a):
        """Lista de FilaDominancia, una por fila de A."""
        return [FilaDominancia(i + 1, abs(a[i][i]), sum(abs(v) for j, v in enumerate(a[i]) if j != i))
                for i in range(len(a))]

    @classmethod
    def es_dominante(cls, a):
        """Dominancia estricta por filas: |a_ii| > Σ|a_ij| en todas las filas."""
        return all(f.estricta for f in cls.filas(a))

    @staticmethod
    def _razon(fila, columna):
        """|a_jj| / Σ|resto| de `fila` si se coloca en la posición `columna` (inf si el resto es 0)."""
        resto = sum(abs(v) for j, v in enumerate(fila) if j != columna)
        return math.inf if resto == 0 else abs(fila[columna]) / resto

    @classmethod
    def reordenar(cls, a):
        """Busca la permutación de filas sin ceros en la diagonal con mejor dominancia; None si no existe."""
        n = len(a)
        mejor, puntaje = None, -1.0
        for perm in permutations(range(n)):
            if any(a[fila][j] == 0 for j, fila in enumerate(perm)):
                continue
            valor = min(cls._razon(a[fila], j) for j, fila in enumerate(perm))
            if valor > puntaje:
                mejor, puntaje = list(perm), valor
        if mejor is None:
            return None
        return Reordenamiento(mejor, puntaje > 1, mejor != list(range(n)))


@dataclass
class Iteracion:
    """Una iteración: número k, aproximación x⁽ᵏ⁾, error ‖x⁽ᵏ⁾ − x⁽ᵏ⁻¹⁾‖∞ y residuo ‖Ax − b‖∞."""
    k: int
    x: list
    error: float
    residuo: float


@dataclass
class ResultadoIterativo:
    """Resultado de un método: estado final, solución, residuo y tabla de iteraciones."""
    metodo: str
    estado: str  # convergencia | max_iteraciones | divergencia | no_finito
    mensaje: str
    iteraciones: list
    advertencias: list = field(default_factory=list)

    @property
    def converge(self):
        """True si se alcanzó la tolerancia."""
        return self.estado == "convergencia"

    @property
    def solucion(self):
        """Última aproximación calculada."""
        return self.iteraciones[-1].x

    @property
    def residuo(self):
        """Residuo de la última aproximación."""
        return self.iteraciones[-1].residuo

    @property
    def errores(self):
        """Errores finitos por iteración, para la gráfica."""
        return [it.error for it in self.iteraciones if math.isfinite(it.error)]


class MetodoIterativo:
    """Esquema común: repetir pasos hasta tolerancia, máximo de iteraciones o divergencia."""
    nombre = ""

    def _siguiente(self, s, x):
        """Calcula x⁽ᵏ⁺¹⁾ a partir de x⁽ᵏ⁾ (lo define cada método)."""
        raise NotImplementedError

    @staticmethod
    def _error(nuevo, viejo):
        """‖x⁽ᵏ⁾ − x⁽ᵏ⁻¹⁾‖∞; inf si hay valores no finitos."""
        if not all(math.isfinite(v) for v in nuevo):
            return math.inf
        return max(abs(u - v) for u, v in zip(nuevo, viejo))

    @staticmethod
    def _parada(error, tolerancia):
        """Estado que detiene el proceso, o None si hay que seguir."""
        if not math.isfinite(error):
            return "no_finito"
        if error <= tolerancia:
            return "convergencia"
        return "divergencia" if error > LIMITE_DIVERGENCIA else None

    def resolver(self, s):
        """Itera desde x⁽⁰⁾ y devuelve un ResultadoIterativo."""
        x, filas = list(s.x0), []
        for k in range(1, s.maximo + 1):
            nuevo = self._siguiente(s, x)
            error = self._error(nuevo, x)
            filas.append(Iteracion(k, nuevo, error, s.residuo(nuevo)))
            x = nuevo
            estado = self._parada(error, s.tolerancia)
            if estado:
                return self._resultado(estado, filas, s)
        return self._resultado("max_iteraciones", filas, s)

    MENSAJES = {
        "convergencia": "Convergencia alcanzada: ‖x⁽ᵏ⁾ − x⁽ᵏ⁻¹⁾‖∞ ≤ ε",
        "max_iteraciones": "Se llegó al máximo de iteraciones sin alcanzar la tolerancia: posible no convergencia",
        "divergencia": "El error superó 1e12: el método diverge",
        "no_finito": "Aparecieron valores no finitos (inf o nan): el método diverge",
    }

    def _resultado(self, estado, filas, s):
        """Arma el resultado y las advertencias (por ejemplo, error creciente)."""
        mensaje = f"{self.MENSAJES[estado]} (k = {len(filas)})"
        avisos = []
        if estado != "convergencia" and len(filas) > 1 and filas[-1].error > filas[0].error:
            avisos.append("El error al final es mayor que en la primera iteración: el error crece.")
        if estado != "convergencia":
            avisos.append("Esto no demuestra por sí solo que el método diverja siempre: depende de A.")
        return ResultadoIterativo(self.nombre, estado, mensaje, filas, avisos)


class Jacobi(MetodoIterativo):
    """Jacobi: todos los componentes nuevos usan solo valores de la iteración anterior."""
    nombre = "Jacobi"

    def _siguiente(self, s, x):
        """x_i⁽ᵏ⁺¹⁾ = (b_i − Σ_{j≠i} a_ij · x_j⁽ᵏ⁾) / a_ii."""
        return [(s.b[i] - sum(a * x[j] for j, a in enumerate(s.a[i]) if j != i)) / s.a[i][i]
                for i in range(len(x))]


class GaussSeidel(MetodoIterativo):
    """Gauss-Seidel: cada componente recién calculado se usa de inmediato en la misma iteración."""
    nombre = "Gauss-Seidel"

    def _siguiente(self, s, x):
        """Actualiza una copia de x componente a componente, reutilizando los nuevos valores."""
        nuevo = list(x)
        for i in range(len(x)):
            nuevo[i] = (s.b[i] - sum(a * nuevo[j] for j, a in enumerate(s.a[i]) if j != i)) / s.a[i][i]
        return nuevo


@dataclass
class Informe:
    """Todo lo que muestran la consola y la página para un sistema."""
    filas_dominancia: list
    ceros: list
    dominante: bool
    reordenamiento: object  # Reordenamiento | None
    aplicado: bool
    a_usada: list
    b_usado: list
    bloqueo: str = ""
    resultados: list = field(default_factory=list)
    referencia: object = None  # lista de float o None
    nota_referencia: str = ""

    def comparacion(self):
        """Texto: método con menos iteraciones y diferencia entre soluciones (si ambos convergen)."""
        if len(self.resultados) < 2:
            return []
        jacobi, seidel = self.resultados
        if not (jacobi.converge and seidel.converge):
            return ["No se compara: al menos un método no alcanzó la tolerancia."]
        n1, n2 = len(jacobi.iteraciones), len(seidel.iteraciones)
        ganador = "Jacobi y Gauss-Seidel necesitaron las mismas iteraciones" if n1 == n2 else (
            f"{'Jacobi' if n1 < n2 else 'Gauss-Seidel'} necesitó menos iteraciones")
        diferencia = max(abs(u - v) for u, v in zip(jacobi.solucion, seidel.solucion))
        return [f"{ganador} (Jacobi: {n1}, Gauss-Seidel: {n2}).",
                f"Diferencia entre las dos soluciones: ‖x_J − x_GS‖∞ = {diferencia:.3e}."]

    def diferencia_con_referencia(self, resultado):
        """‖x_aprox − x_ref‖∞ o None si no hay referencia o el método no convergió."""
        if self.referencia is None or not resultado.converge:
            return None
        return max(abs(u - v) for u, v in zip(resultado.solucion, self.referencia))


class ProblemaIterativo:
    """Orquesta el análisis de la diagonal, el reordenamiento opcional y los dos métodos."""

    @staticmethod
    def _referencia(a, b):
        """Solución exacta por el Gauss-Jordan de la calculadora (float) o (None, motivo)."""
        sistema = SistemaLineal.desde_matriz(a, b)
        diagnostico = sistema.diagnosticar(sistema.reducir())
        if diagnostico.tipo != "determinado":
            return None, f"Sin solución de referencia única: el sistema es {diagnostico.tipo}."
        return [float(diagnostico.solucion[j]) for j in range(len(b))], "Gauss-Jordan de la calculadora"

    @staticmethod
    def _reordenar(a, b, aplicar):
        """Devuelve (A, b, reordenamiento propuesto, ¿se aplicó?) según la opción del usuario."""
        propuesta = AnalisisDiagonal.reordenar(a)
        if aplicar and propuesta and propuesta.cambia:
            return ([a[i] for i in propuesta.permutacion], [b[i] for i in propuesta.permutacion], propuesta, True)
        return a, b, propuesta, False

    @classmethod
    def ejecutar(cls, a, b, x0, tolerancia, maximo, reordenar=False):
        """Valida, analiza y resuelve con ambos métodos; `a` y `b` son Matriz de Fraction y lista de Fraction."""
        sistema = SistemaIterativo.validar(a.datos, b, x0, tolerancia, maximo)
        usada, b_usado, propuesta, aplicado = cls._reordenar(sistema.a, sistema.b, reordenar)
        informe = Informe(AnalisisDiagonal.filas(usada), AnalisisDiagonal.ceros(usada),
                          AnalisisDiagonal.es_dominante(usada), propuesta, aplicado, usada, b_usado)
        informe.referencia, informe.nota_referencia = cls._referencia(a, b)
        if informe.ceros:
            informe.bloqueo = ("Hay ceros en la diagonal principal (fila(s) "
                               + ", ".join(map(str, informe.ceros)) + "): no se puede dividir entre a_ii.")
            return informe
        sistema.a, sistema.b = usada, b_usado
        informe.resultados = [Jacobi().resolver(sistema), GaussSeidel().resolver(sistema)]
        return informe


CASOS_ITERATIVOS = [
    {"nombre": "Caso 1 · Convergencia", "objetivo": "Matriz estrictamente diagonal dominante: ambos métodos convergen y Gauss-Seidel usa menos iteraciones.",
     "A": [[10, -1, 2, 0], [-1, 11, -1, 3], [2, -1, 10, -1], [0, 3, -1, 8]], "b": [6, 25, -11, 15],
     "x0": [0, 0, 0, 0], "tol": "1e-6", "nmax": 100, "reordenar": False},
    {"nombre": "Caso 2 · Reordenamiento", "objetivo": "Hay un 0 en la diagonal: se reordenan las filas para poder continuar (queda diagonal dominante).",
     "A": [[0, 3, 1], [4, 1, 0], [1, 1, 5]], "b": [7, 6, 8], "x0": [0, 0, 0], "tol": "1e-6", "nmax": 100, "reordenar": True},
    {"nombre": "Caso 2b · Sin reordenamiento válido", "objetivo": "Una columna de ceros: ninguna permutación quita los ceros de la diagonal, y no se fuerza.",
     "A": [[0, 1, 2], [0, 3, 1], [0, 2, 5]], "b": [1, 2, 3], "x0": [0, 0, 0], "tol": "1e-6", "nmax": 100, "reordenar": True},
    {"nombre": "Caso 3 · No convergencia", "objetivo": "No es diagonal dominante y el error crece: ambos métodos divergen (se avisa sin cerrar el programa).",
     "A": [[1, 2], [3, 1]], "b": [3, 4], "x0": [0, 0], "tol": "1e-6", "nmax": 50, "reordenar": False},
    {"nombre": "Caso 3b · No dominante pero converge", "objetivo": "No cumple la condición suficiente y aun así converge: no cumplirla no prueba divergencia.",
     "A": [[4, 5], [1, 3]], "b": [9, 4], "x0": [0, 0], "tol": "1e-6", "nmax": 100, "reordenar": False},
]
