"""Acciones web de los Programas 7 y 8: Bisección, gráficas, errores numéricos, Jacobi y Gauss-Seidel.
Cada método recibe un diccionario del navegador y devuelve datos simples (texto y números) para dibujar.
Elaborado por: [Integrantes del grupo: completar nombres].
"""
from .evaluador_seguro import ErrorNumerico, FuncionSegura, formato, leer_numero
from .interfaz import Entrada
from .modulo_matrices import Matriz
from .numerico_biseccion import Biseccion, contrastar_con_scipy, fila_a_texto
from .numerico_errores import CalculoErrores, NotacionPosicional, PropagacionError, PuntoFlotante, TiposDeError
from .numerico_grafica import GraficadorFunciones
from .numerico_iterativos import CASOS_ITERATIVOS, ProblemaIterativo

COLUMNAS = ["k", "a", "b", "xr", "f(a)", "f(b)", "f(xr)", "Eb", "εa"]


class ServicioNumerico:
    """Acciones `num_*` del servicio web."""

    def acciones(self):
        """Diccionario nombre → método para registrar en el servicio principal."""
        return {"num_biseccion": self.biseccion, "num_grafica": self.grafica, "num_posicional": self.posicional,
                "num_flotante": self.flotante, "num_tipos": self.tipos, "num_errores": self.errores,
                "num_propagacion": self.propagacion}

    @staticmethod
    def _grafica(datos, extra=None):
        """Convierte DatosGrafica en un diccionario listo para JSON."""
        salida = {"expresion": datos.expresion, "x_min": datos.x_min, "x_max": datos.x_max,
                  "y_min": datos.y_min, "y_max": datos.y_max, "segmentos": datos.segmentos,
                  "descartados": datos.descartados}
        salida.update(extra or {})
        return salida

    def grafica(self, d):
        """Puntos de la función en [x_min, x_max]."""
        funcion = FuncionSegura(d["f"])
        graficador = GraficadorFunciones(funcion, d["f"].strip(), leer_numero(d["x_min"], "x_min"),
                                         leer_numero(d["x_max"], "x_max"))
        return {"grafica": self._grafica(graficador.calcular())}

    def biseccion(self, d):
        """Resuelve con Bisección y devuelve tabla, resumen, comparación con SciPy y la gráfica."""
        funcion = FuncionSegura(d["f"])
        problema = Biseccion(funcion, leer_numero(d["a"], "a"), leer_numero(d["b"], "b"),
                             leer_numero(d["e"], "E"), self._entero(d["nmax"]))
        resultado = problema.resolver()
        salida = {"mensaje": resultado.mensaje, "ok": resultado.encontro_raiz, "n_teorico": resultado.n_teorico,
                  "ejecutadas": len(resultado.iteraciones), "advertencias": resultado.advertencias,
                  "columnas": COLUMNAS, "filas": [fila_a_texto(i) for i in resultado.iteraciones]}
        if resultado.encontro_raiz:
            salida.update(self._detalle_raiz(resultado, funcion, problema, d["f"].strip()))
        return salida

    @staticmethod
    def _entero(valor):
        """Entero de la interfaz o ErrorNumerico claro."""
        from .evaluador_seguro import ErrorNumerico
        try:
            return int(str(valor).strip())
        except ValueError:
            raise ErrorNumerico("Las iteraciones máximas deben ser un número entero") from None

    def _detalle_raiz(self, resultado, funcion, problema, expresion):
        """Raíz, errores, comparación con SciPy y datos de la gráfica con intervalo inicial."""
        extra = {"raiz": resultado.raiz, "raiz_txt": formato(resultado.raiz, 10),
                 "f_raiz": formato(resultado.f_raiz, 6), "cota": formato(resultado.cota_error, 6)}
        if resultado.es_confiable:
            valor, motivo = contrastar_con_scipy(funcion, problema.a0, problema.b0)
            extra["scipy"] = motivo if valor is None else (
                f"scipy.optimize.bisect = {valor:.10g} (diferencia absoluta {abs(valor - resultado.raiz):.3e})")
        margen = 0.25 * (problema.b0 - problema.a0)
        datos = GraficadorFunciones(funcion, expresion, problema.a0 - margen, problema.b0 + margen).calcular()
        extra["grafica"] = self._grafica(datos, {"raiz": resultado.raiz, "intervalo": [problema.a0, problema.b0]})
        return extra

    @staticmethod
    def _descomposicion(descomposicion, otra):
        """Datos de una Descomposicion para mostrar."""
        return {"etiqueta": descomposicion.etiqueta(), "expresion": descomposicion.expresion(),
                "suma": descomposicion.suma(), "valor": f"({otra.signo}{descomposicion.valor})₁₀"}

    def posicional(self, d):
        """Descompone el número en su base y en la otra."""
        origen, destino = NotacionPosicional.convertir(d["texto"], int(d["base"]))
        return {"origen": self._descomposicion(origen, destino), "destino": self._descomposicion(destino, origen),
                "iguales": origen.valor == destino.valor}

    def flotante(self, d):
        """0.1 + 0.2, épsilon de máquina, overflow y underflow."""
        suma = PuntoFlotante.suma_01_02()
        suma["diferencia"] = f"{suma['diferencia']:.3e}"
        return {"suma": suma, "eps": PuntoFlotante.epsilon_maquina(), "casos": PuntoFlotante.overflow_y_underflow()}

    def tipos(self, d):
        """Los seis tipos de error."""
        return {"tipos": [{"nombre": t.nombre, "definicion": t.definicion, "ejemplo": t.ejemplo}
                          for t in TiposDeError.lista()]}

    def errores(self, d):
        """Error absoluto, relativo y porcentual."""
        absoluto, relativo, porcentual = CalculoErrores.calcular(leer_numero(d["xv"], "xv"), leer_numero(d["xa"], "xa"))
        return {"absoluto": f"{absoluto:.10g}", "relativo": None if relativo is None else f"{relativo:.10g}",
                "porcentual": None if porcentual is None else f"{porcentual:.10g}"}

    def propagacion(self, d):
        """Propagación del error para sen(x) + x²."""
        r = PropagacionError.calcular(leer_numero(d["x"], "x"), leer_numero(d["dx"], "Δx"))
        return {clave: (f"{valor:.3e}" if clave == "diferencia" else f"{valor:.10g}") for clave, valor in r.items()}


class ServicioIterativos:
    """Acciones web del Programa 8: Jacobi y Gauss-Seidel."""

    def acciones(self):
        """Diccionario nombre → método para registrar en el servicio principal."""
        return {"iter_resolver": self.resolver, "iter_casos": self.casos}

    @staticmethod
    def casos(d):
        """Los casos de prueba del programa (datos y objetivo)."""
        return {"casos": CASOS_ITERATIVOS}

    def resolver(self, d):
        """Analiza la diagonal y ejecuta Jacobi y Gauss-Seidel con los datos de la página."""
        a = Matriz([[self._numero(c, f"A[{i + 1}][{j + 1}]") for j, c in enumerate(fila)] for i, fila in enumerate(d["A"])])
        b = [self._numero(v, f"b[{i + 1}]") for i, v in enumerate(d["b"])]
        x0 = [self._numero(v, f"x⁽⁰⁾[{i + 1}]") for i, v in enumerate(d["x0"])]
        informe = ProblemaIterativo.ejecutar(a, b, x0, leer_numero(d["tol"], "ε"),
                                             ServicioNumerico._entero(d["nmax"]), bool(d.get("reordenar")))
        return {"analisis": self._analisis(informe), "bloqueo": informe.bloqueo,
                "metodos": [self._metodo(r, informe) for r in informe.resultados],
                "comparacion": informe.comparacion(), "referencia": self._referencia(informe)}

    @staticmethod
    def _numero(texto, nombre):
        """Celda de texto a Fraction exacta; ErrorNumerico indicando cuál celda falla."""
        try:
            return Entrada.texto_a_fraccion(str(texto))
        except ValueError:
            raise ErrorNumerico(f"{nombre} no es un número válido. Revise las celdas en rojo.") from None

    @staticmethod
    def _referencia(informe):
        """Solución de referencia como texto, o None si no hay."""
        if informe.referencia is None:
            return {"texto": None, "nota": informe.nota_referencia}
        return {"texto": [formato(v, 10) for v in informe.referencia], "nota": informe.nota_referencia}

    @staticmethod
    def _analisis(informe):
        """Dominancia por filas, ceros y reordenamiento propuesto."""
        propuesta = informe.reordenamiento
        return {"filas": [{"fila": f.fila, "diag": formato(f.diagonal), "resto": formato(f.resto), "ok": f.estricta}
                          for f in informe.filas_dominancia],
                "ceros": informe.ceros, "dominante": informe.dominante, "aplicado": informe.aplicado,
                "matriz": [[formato(v) for v in fila] for fila in informe.a_usada],
                "b": [formato(v) for v in informe.b_usado],
                "propuesta": None if propuesta is None else {
                    "orden": [i + 1 for i in propuesta.permutacion], "dominante": propuesta.dominante,
                    "cambia": propuesta.cambia}}

    @staticmethod
    def _metodo(r, informe):
        """Tabla de iteraciones, resumen y validación de un método."""
        diferencia = informe.diferencia_con_referencia(r)
        return {"nombre": r.metodo, "estado": r.estado, "ok": r.converge, "mensaje": r.mensaje,
                "advertencias": r.advertencias, "n": len(r.iteraciones), "residuo": formato(r.residuo, 6),
                "solucion": [formato(v, 10) for v in r.solucion],
                "dif_referencia": None if diferencia is None else f"{diferencia:.3e}",
                "filas": [[str(it.k)] + [formato(v, 8) for v in it.x] + [formato(it.error, 6), formato(it.residuo, 6)]
                          for it in r.iteraciones],
                "errores": [it.error if it.error < 1e300 else 1e300 for it in r.iteraciones if it.error == it.error]}
