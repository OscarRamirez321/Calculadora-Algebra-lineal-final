"""Módulo B: cálculo de los puntos de la gráfica de f(x) y dibujo opcional con Matplotlib.
La lógica evalúa f de forma controlada, descarta valores no reales o no finitos y corta la
curva en asíntotas y discontinuidades. El dibujo en consola usa Matplotlib si está instalada.
Elaborado por: [Integrantes del grupo: completar nombres].
"""
import math
from dataclasses import dataclass, field

from .evaluador_seguro import ErrorNumerico


@dataclass
class DatosGrafica:
    """Segmentos continuos (listas de pares (x, y)), límites sugeridos y puntos descartados."""
    expresion: str
    x_min: float
    x_max: float
    y_min: float
    y_max: float
    segmentos: list = field(default_factory=list)
    descartados: int = 0


class GraficadorFunciones:
    """Genera los puntos de f en [x_min, x_max] sin unir a través de asíntotas ni zonas no definidas."""

    PUNTOS = 2000
    FACTOR_VENTANA = 1.0  # La ventana vertical se amplía este múltiplo del rango entre percentiles 5 y 95
    FRACCION_SALTO = 0.3  # Un cambio de signo con salto mayor que esta fracción de la ventana corta la curva

    def __init__(self, funcion, expresion, x_min, x_max):
        """Valida el intervalo y guarda la función ya validada."""
        if not (math.isfinite(x_min) and math.isfinite(x_max)):
            raise ErrorNumerico("x_min y x_max deben ser números finitos")
        if x_min >= x_max:
            raise ErrorNumerico(f"x_min ({x_min:g}) debe ser menor que x_max ({x_max:g})")
        self.f, self.expresion, self.x_min, self.x_max = funcion, expresion, float(x_min), float(x_max)

    def _evaluar_puntos(self):
        """Lista de (x, y) con y real y finito, y cuántos puntos se descartaron por no estar definidos."""
        paso = (self.x_max - self.x_min) / (self.PUNTOS - 1)
        puntos, descartados = [], 0
        for i in range(self.PUNTOS):
            x = self.x_min + i * paso
            try:
                puntos.append((x, self.f(x)))
            except ErrorNumerico:
                puntos.append((x, None))
                descartados += 1
        return puntos, descartados

    def _ventana_vertical(self, puntos):
        """Límites (y_min, y_max) robustos: los percentiles 5 y 95 evitan que una asíntota aplaste la gráfica."""
        ys = sorted(y for _, y in puntos if y is not None)
        if not ys:
            raise ErrorNumerico("La función no está definida (no da valores reales) en ningún punto del intervalo")
        bajo, alto = ys[int(0.05 * (len(ys) - 1))], ys[int(0.95 * (len(ys) - 1))]
        margen = (alto - bajo) * self.FACTOR_VENTANA or 1.0
        return max(ys[0], bajo - margen), min(ys[-1], alto + margen)

    def calcular(self):
        """Devuelve los DatosGrafica con los segmentos continuos listos para dibujar."""
        puntos, descartados = self._evaluar_puntos()
        y_min, y_max = self._ventana_vertical(puntos)
        segmentos, actual, previo = [], [], None
        for x, y in puntos:
            dentro = y is not None and y_min <= y <= y_max
            if dentro and previo is not None and self._salto_de_asintota(previo, y, y_max - y_min):
                segmentos.append(actual)
                actual = []
            if dentro:
                actual.append((x, y))
            elif actual:
                segmentos.append(actual)
                actual = []
            previo = y if dentro else None
        if actual:
            segmentos.append(actual)
        segmentos = [s for s in segmentos if len(s) > 1]
        if not segmentos:
            raise ErrorNumerico("No hay suficientes puntos reales para dibujar la función en ese intervalo")
        return DatosGrafica(self.expresion, self.x_min, self.x_max, *self._limites(segmentos), segmentos, descartados)

    def _salto_de_asintota(self, previo, actual, ventana):
        """True si hay cambio de signo con un salto grande: se interpreta como asíntota, no como cruce."""
        return (previo > 0) != (actual > 0) and abs(actual - previo) > self.FRACCION_SALTO * ventana

    @staticmethod
    def _limites(segmentos):
        """Límites verticales ajustados a lo dibujado, con un margen del 8 %."""
        ys = [y for segmento in segmentos for _, y in segmento]
        bajo, alto = min(ys), max(ys)
        margen = (alto - bajo) * 0.08 or 1.0
        return bajo - margen, alto + margen


def dibujar_con_matplotlib(datos, raiz=None, intervalo=None, guardar_en=None):
    """Muestra la gráfica con título, ejes, cuadrícula y leyenda; devuelve '' o el motivo si no se pudo."""
    try:
        import matplotlib
        if guardar_en:
            matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return "Matplotlib no está instalada (pip install matplotlib). Use la versión del navegador o instálela."
    figura, eje = plt.subplots(figsize=(8, 5))
    for numero, segmento in enumerate(datos.segmentos):
        eje.plot([p[0] for p in segmento], [p[1] for p in segmento], color="#2646D6",
                 label=f"f(x) = {datos.expresion}" if numero == 0 else None)
    _anotar(eje, datos, raiz, intervalo)
    eje.set_title(f"Gráfica de f(x) = {datos.expresion}")
    eje.set_xlabel("x")
    eje.set_ylabel("f(x)")
    eje.set_ylim(datos.y_min, datos.y_max)
    eje.grid(True, alpha=0.4)
    eje.legend()
    if guardar_en:
        figura.savefig(guardar_en, dpi=120)
        plt.close(figura)
    else:
        plt.show()
    return ""


def _anotar(eje, datos, raiz, intervalo):
    """Marca el eje x, la raíz aproximada y el intervalo inicial cuando vienen de la Bisección."""
    eje.axhline(0, color="gray", linewidth=0.8)
    if intervalo is not None:
        eje.axvspan(intervalo[0], intervalo[1], color="#FFD84D", alpha=0.25,
                    label=f"Intervalo inicial [{intervalo[0]:g}, {intervalo[1]:g}]")
    if raiz is not None:
        eje.plot([raiz], [0], "o", color="#C62828", label=f"Raíz aproximada xr = {raiz:.8g}")
