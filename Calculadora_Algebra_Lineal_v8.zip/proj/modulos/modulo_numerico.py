"""Módulo de Métodos Numéricos (Programa 7): Bisección, graficador, notación posicional y errores.
Menú de consola que lee y valida los datos, llama a las clases de cálculo y muestra los resultados.
Cada dato inválido muestra un mensaje claro y se vuelve a pedir sin cerrar el programa.
Elaborado por: [Integrantes del grupo: completar nombres].
"""
from .evaluador_seguro import ErrorNumerico, FuncionSegura, formato, leer_numero
from .interfaz import Consola, Entrada, Estilo
from .numerico_biseccion import Biseccion, contrastar_con_scipy, fila_a_texto
from .numerico_errores import CalculoErrores, NotacionPosicional, PropagacionError, PuntoFlotante, TiposDeError
from .numerico_grafica import GraficadorFunciones, dibujar_con_matplotlib

LOGO_NUMERICO = r"""
  #   # #   # #   # #####  ####  ###   ###   ###   ####
  ##  # #   # ## ## #     #   #   #   #   # #   # #
  # # # #   # # # # ####  #####   #   #     #   #  ###
  #  ## #   # #   # #     #   #   #   #   # #   #     #
  #   #  ###  #   # ##### #   #  ###   ###   ###  ####
  ------  M É T O D O S   N U M É R I C O S  ------
"""
ENCABEZADOS_TABLA = ["k", "a", "b", "xr", "f(a)", "f(b)", "f(xr)", "Eb", "εa"]


class MenuNumerico:
    """Menú del Programa 7 con sus cuatro opciones."""

    def ejecutar(self):
        """Muestra el logo y atiende el menú hasta que el usuario vuelve atrás."""
        Consola.logo(LOGO_NUMERICO)
        acciones = {"1": self._biseccion, "2": self._graficador, "3": self._notacion, "4": self._errores}
        while True:
            Consola.encabezado("MÉTODOS NUMÉRICOS")
            Consola.opcion("1", "Método de Bisección")
            Consola.opcion("2", "Graficador de funciones")
            Consola.opcion("3", "Notación posicional (base 10 y base 2)")
            Consola.opcion("4", "Errores numéricos")
            Consola.opcion("S", "Volver al menú principal")
            opcion = Entrada.opcion("\n  Seleccione una opción: ", list(acciones) + ["s"])
            if opcion == "s":
                return
            acciones[opcion]()
            Consola.pausar()

    # ---------- lectura validada ----------

    @staticmethod
    def _leer(mensaje, convertir):
        """Repite la pregunta hasta que `convertir` acepte el texto; muestra el error si no."""
        while True:
            try:
                return convertir(input(mensaje))
            except ErrorNumerico as error:
                Consola.error(str(error))

    def _leer_funcion(self):
        """Pide f(x) hasta que sea una expresión válida; devuelve (texto, FuncionSegura)."""
        Consola.info("Escriba f(x) con ** para potencias (ej. x**3 - 2*x - 5). Permitidas: sin, cos, tan, exp, log, sqrt, abs, pi, e.")
        texto = self._leer("  f(x) = ", lambda t: (t.strip(), FuncionSegura(t)))
        return texto

    @staticmethod
    def _entero(texto):
        """Convierte a entero ≥ 1 o lanza ErrorNumerico."""
        try:
            return int(texto)
        except ValueError:
            raise ErrorNumerico("Escriba un número entero (por ejemplo 100)") from None

    def _leer_problema(self):
        """Pide función, intervalo, tolerancia y máximo; si no son válidos vuelve a pedirlos."""
        expresion, funcion = self._leer_funcion()
        while True:
            a = self._leer("  Extremo inferior a: ", lambda t: leer_numero(t, "a"))
            b = self._leer("  Extremo superior b: ", lambda t: leer_numero(t, "b"))
            tolerancia = self._leer("  Tolerancia absoluta E (ej. 1e-4): ", lambda t: leer_numero(t, "E"))
            maximo = self._leer("  Iteraciones máximas: ", self._entero)
            try:
                return expresion, funcion, Biseccion(funcion, a, b, tolerancia, maximo)
            except ErrorNumerico as error:
                Consola.error(str(error))

    # ---------- opción 1: Bisección ----------

    def _biseccion(self):
        """Opción 1: resuelve con Bisección y permite corregir los datos si el intervalo no sirve."""
        Consola.seccion("Método de Bisección")
        while True:
            expresion, funcion, problema = self._leer_problema()
            try:
                resultado = problema.resolver()
            except ErrorNumerico as error:
                Consola.error(str(error))
                resultado = None
            if resultado is not None:
                self._mostrar_biseccion(expresion, funcion, problema, resultado)
            if not Entrada.si_no("\n  ¿Probar con otros datos? [s/n]: "):
                return

    def _mostrar_biseccion(self, expresion, funcion, problema, resultado):
        """Muestra n teórico, la tabla, el resumen y la comparación con SciPy."""
        Consola.info(f"n mínimo teórico = ⌈log₂((b − a)/E)⌉ = {resultado.n_teorico}")
        if resultado.iteraciones:
            self._imprimir_tabla(resultado)
        (Consola.exito if resultado.encontro_raiz else Consola.error)(resultado.mensaje)
        for aviso in resultado.advertencias:
            Consola.aviso(aviso)
        if resultado.encontro_raiz:
            self._imprimir_resumen(resultado, funcion, problema)
            if Entrada.si_no("  ¿Graficar la función con la raíz marcada? [s/n]: "):
                self._graficar(expresion, funcion, problema, resultado.raiz)

    @staticmethod
    def _imprimir_tabla(resultado):
        """Tabla con los valores usados para calcular cada xr (antes de actualizar el intervalo)."""
        Consola.info("La tabla registra a y b ANTES de actualizar el intervalo (los usados para calcular xr).")
        print("  " + "".join(f"{h:>14}" for h in ENCABEZADOS_TABLA))
        for iteracion in resultado.iteraciones:
            print("  " + "".join(f"{valor:>14}" for valor in fila_a_texto(iteracion)))

    @staticmethod
    def _imprimir_resumen(resultado, funcion, problema):
        """Raíz, f(raíz), cota del error, iteraciones y diferencia con scipy.optimize.bisect."""
        print(f"\n  Raíz aproximada xr = {resultado.raiz:.10g}")
        print(f"  f(xr) = {formato(resultado.f_raiz, 6)}   |   Cota del error Eb = {formato(resultado.cota_error, 6)}")
        print(f"  Iteraciones: teóricas = {resultado.n_teorico}, ejecutadas = {len(resultado.iteraciones)}")
        if not resultado.es_confiable:
            Consola.aviso("No se compara con SciPy: no se cumplen todas las condiciones del método.")
            return
        valor, motivo = contrastar_con_scipy(funcion, problema.a0, problema.b0)
        if valor is None:
            Consola.aviso(motivo)
        else:
            print(f"  scipy.optimize.bisect = {valor:.10g}   |   diferencia absoluta = {abs(valor - resultado.raiz):.3e}")

    # ---------- opción 2: graficador ----------

    def _graficador(self):
        """Opción 2: pide función y límites y dibuja la gráfica."""
        Consola.seccion("Graficador de funciones")
        expresion, funcion = self._leer_funcion()
        while True:
            x_min = self._leer("  x_min: ", lambda t: leer_numero(t, "x_min"))
            x_max = self._leer("  x_max: ", lambda t: leer_numero(t, "x_max"))
            try:
                datos = GraficadorFunciones(funcion, expresion, x_min, x_max).calcular()
                break
            except ErrorNumerico as error:
                Consola.error(str(error))
        Consola.info(f"{sum(len(s) for s in datos.segmentos)} puntos dibujados; {datos.descartados} descartados (no definidos).")
        self._dibujar(datos)

    @staticmethod
    def _dibujar(datos, raiz=None, intervalo=None):
        """Abre la gráfica con Matplotlib o explica cómo instalarla."""
        motivo = dibujar_con_matplotlib(datos, raiz, intervalo)
        if motivo:
            Consola.aviso(motivo)

    def _graficar(self, expresion, funcion, problema, raiz):
        """Grafica la función de la Bisección marcando la raíz y el intervalo inicial."""
        margen = 0.25 * (problema.b0 - problema.a0)
        try:
            datos = GraficadorFunciones(funcion, expresion, problema.a0 - margen, problema.b0 + margen).calcular()
        except ErrorNumerico as error:
            Consola.error(str(error))
            return
        Consola.info(f"Se representa el intervalo inicial [{problema.a0:g}, {problema.b0:g}] (zona sombreada).")
        self._dibujar(datos, raiz, (problema.a0, problema.b0))

    # ---------- opción 3: notación posicional ----------

    def _notacion(self):
        """Opción 3: descompone un entero en base 10 o 2 y lo convierte a la otra base."""
        Consola.seccion("Notación posicional")
        Consola.info("Ejemplos: (84506)₁₀ en base 10 y (11110011)₂ en base 2. Un signo negativo se conserva.")
        Consola.opcion("1", "El número está en base 10")
        Consola.opcion("2", "El número está en base 2")
        base = 10 if Entrada.opcion("  Base de origen: ", ["1", "2"]) == "1" else 2
        origen, destino = self._leer(f"  Número en base {base}: ", lambda t: NotacionPosicional.convertir(t, base))
        for descomposicion, otra in ((origen, destino), (destino, origen)):
            print(f"\n  Base de origen {descomposicion.base} → base del resultado {otra.base}")
            print(f"  {descomposicion.etiqueta()} = {descomposicion.expresion()}")
            print(f"  {descomposicion.etiqueta()} = {descomposicion.suma()} = ({otra.signo}{descomposicion.valor})₁₀")
        Consola.exito("Los valores decimal y binario son equivalentes" if origen.valor == destino.valor else "Valores distintos")

    # ---------- opción 4: errores numéricos ----------

    def _errores(self):
        """Opción 4: submenú de punto flotante, tipos de error, cálculo de errores y propagación."""
        acciones = {"1": self._punto_flotante, "2": self._tipos_de_error, "3": self._calcular_errores,
                    "4": self._propagacion}
        Consola.seccion("Errores numéricos")
        Consola.opcion("1", "Punto flotante: 0.1 + 0.2, épsilon, overflow y underflow")
        Consola.opcion("2", "Tipos de error con ejemplos")
        Consola.opcion("3", "Error absoluto y relativo")
        Consola.opcion("4", "Propagación del error: f(x) = sen(x) + x²")
        acciones[Entrada.opcion("  Opción: ", list(acciones))]()

    @staticmethod
    def _punto_flotante():
        """Muestra 0.1 + 0.2 == 0.3, el épsilon de máquina y ejemplos de overflow/underflow."""
        suma, eps = PuntoFlotante.suma_01_02(), PuntoFlotante.epsilon_maquina()
        print(f"\n  0.1 + 0.2 == 0.3  →  {suma['igual']}   (0.1 + 0.2 = {suma['suma']})")
        print(f"  0.1 se guarda como {suma['exacto_0_1']}…")
        Consola.info("0.1, 0.2 y 0.3 no tienen representación binaria exacta; se guardan redondeados y el error se acumula.")
        print(f"\n  Épsilon de máquina ({eps['fuente']}) = {eps['eps']!r}")
        Consola.info("Es la distancia entre 1.0 y el siguiente float mayor en doble precisión.")
        for caso in PuntoFlotante.overflow_y_underflow():
            print(f"\n  {caso['tipo']}: {caso['ejemplo']} → {caso['resultado']}\n    {caso['explicacion']}")
        Consola.aviso("El comportamiento puede variar según el equipo y el tipo de dato; no es universal.")

    @staticmethod
    def _tipos_de_error():
        """Muestra la definición y un ejemplo de cada tipo de error."""
        for tipo in TiposDeError.lista():
            Consola.seccion(tipo.nombre)
            print(f"  {tipo.definicion}\n  Ejemplo: {tipo.ejemplo}")

    def _calcular_errores(self):
        """Pide valor verdadero y aproximado; no divide entre cero si xv = 0."""
        xv = self._leer("  Valor verdadero xv: ", lambda t: leer_numero(t, "xv"))
        xa = self._leer("  Valor aproximado xa: ", lambda t: leer_numero(t, "xa"))
        absoluto, relativo, porcentual = CalculoErrores.calcular(xv, xa)
        print(f"\n  Error absoluto Ea = |xv − xa| = {absoluto:.10g}")
        if relativo is None:
            Consola.aviso("xv = 0: el error relativo y el porcentual no están definidos.")
        else:
            print(f"  Error relativo Er = {relativo:.10g}\n  Error relativo porcentual = {porcentual:.10g} %")

    def _propagacion(self):
        """Compara el cambio aproximado f'(x)·Δx con el cambio real f(x + Δx) − f(x)."""
        x = self._leer("  x: ", lambda t: leer_numero(t, "x"))
        delta = self._leer("  Perturbación Δx: ", lambda t: leer_numero(t, "Δx"))
        r = PropagacionError.calcular(x, delta)
        print(f"\n  f(x) = {r['fx']:.10g}   f'(x) = cos(x) + 2x = {r['derivada']:.10g}")
        print(f"  Δy aproximado = f'(x)·Δx = {r['aproximado']:.10g}\n  Δy real = f(x + Δx) − f(x) = {r['real']:.10g}")
        print(f"  Diferencia absoluta = {r['diferencia']:.3e}")
        Consola.info("La derivada da una aproximación de primer orden: funciona mejor para Δx pequeño.")
