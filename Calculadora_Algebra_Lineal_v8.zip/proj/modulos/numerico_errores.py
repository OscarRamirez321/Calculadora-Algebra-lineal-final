"""Módulos C y D: notación posicional (base 10 y base 2) y errores numéricos.
Descompone enteros en dígitos por potencias, explica el punto flotante (0.1 + 0.2, épsilon,
overflow y underflow) y calcula errores absoluto, relativo y propagación. Sin input() ni print().
Elaborado por: [Integrantes del grupo: completar nombres].
"""
import math
import sys
import warnings
from dataclasses import dataclass
from decimal import Decimal

from .evaluador_seguro import ErrorNumerico

SUPERINDICES = str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")
SUBINDICES = str.maketrans("0123456789", "₀₁₂₃₄₅₆₇₈₉")


@dataclass
class Descomposicion:
    """Un entero escrito en una base: dígitos, términos dígito·base^potencia y su suma."""
    base: int
    texto: str  # |n| escrito en esa base
    signo: str  # "" o "-"
    terminos: list  # [(dígito, potencia)] de la potencia mayor a la menor
    valor: int  # |n| como entero

    def etiqueta(self):
        """El número con su base: (84506)₁₀."""
        return f"({self.signo}{self.texto}){str(self.base).translate(SUBINDICES)}"

    def expresion(self):
        """Suma de términos: 8 · 10⁴ + 4 · 10³ + ..."""
        partes = [f"{d} · {self.base}{str(p).translate(SUPERINDICES)}" for d, p in self.terminos]
        return " + ".join(partes)

    def suma(self):
        """Valores numéricos de cada término y su total: 80000 + 4000 + ... = 84506."""
        valores = [d * self.base ** p for d, p in self.terminos]
        return " + ".join(str(v) for v in valores)


class NotacionPosicional:
    """Descompone un entero en base 10 o base 2 y lo convierte a la otra base."""

    @staticmethod
    def _leer(texto, base):
        """Valida el texto (con signo opcional) y devuelve (signo, dígitos)."""
        limpio = texto.strip().replace(" ", "")
        signo = "-" if limpio.startswith("-") else ""
        digitos = limpio[1:] if limpio[:1] in ("+", "-") else limpio
        validos = "0123456789" if base == 10 else "01"
        if not digitos or any(c not in validos for c in digitos):
            nombre = "decimal (dígitos 0-9)" if base == 10 else "binario (solo 0 y 1)"
            raise ErrorNumerico(f"«{texto}» no es un entero {nombre}")
        return signo, digitos.lstrip("0") or "0"

    @classmethod
    def descomponer(cls, texto, base):
        """Descompone el número escrito en `base` (10 o 2); el signo se conserva y se descompone |n|."""
        signo, digitos = cls._leer(texto, base)
        longitud = len(digitos)
        terminos = [(int(d), longitud - 1 - i) for i, d in enumerate(digitos)]
        return Descomposicion(base, digitos, signo, terminos, int(digitos, base))

    @classmethod
    def convertir(cls, texto, base_origen):
        """Devuelve (descomposición en la base de origen, descomposición en la otra base)."""
        origen = cls.descomponer(texto, base_origen)
        base_destino = 2 if base_origen == 10 else 10
        valor = origen.valor
        escrito = format(valor, "b") if base_destino == 2 else str(valor)
        destino = cls.descomponer(origen.signo + escrito, base_destino)
        return origen, destino


@dataclass
class EjemploError:
    """Un tipo de error con su definición y un ejemplo calculado."""
    nombre: str
    definicion: str
    ejemplo: str


class PuntoFlotante:
    """Demostraciones controladas del comportamiento de float (doble precisión)."""

    @staticmethod
    def suma_01_02():
        """Ejecuta 0.1 + 0.2 == 0.3 y devuelve los datos para explicar el resultado."""
        suma = 0.1 + 0.2
        return {"suma": repr(suma), "igual": suma == 0.3, "exacto_0_1": str(Decimal(0.1)),
                "exacto_0_2": str(Decimal(0.2)), "exacto_0_3": str(Decimal(0.3)),
                "diferencia": abs(suma - 0.3), "con_tolerancia": math.isclose(suma, 0.3)}

    @staticmethod
    def epsilon_maquina():
        """Épsilon de máquina de float; usa numpy.finfo(float).eps si NumPy está instalada."""
        try:
            import numpy
            valor, fuente = float(numpy.finfo(float).eps), "numpy.finfo(float).eps"
        except ImportError:
            valor, fuente = sys.float_info.epsilon, "sys.float_info.epsilon (NumPy no está instalada)"
        return {"eps": valor, "fuente": fuente, "uno_mas_eps": 1.0 + valor > 1.0,
                "uno_mas_mitad": 1.0 + valor / 2 == 1.0, "siguiente": 1.0 + valor}

    @classmethod
    def overflow_y_underflow(cls):
        """Ejemplos controlados: lista de dicts con ejemplo, resultado y explicación."""
        with warnings.catch_warnings(record=True) as avisos:
            warnings.simplefilter("always")
            casos = [cls._grande(), cls._potencia(), cls._pequeno(), cls._gradual()]
        casos[0]["aviso"] = "; ".join(str(a.message) for a in avisos) or "sin advertencia"
        return casos

    @staticmethod
    def _grande():
        """Overflow: el resultado excede el mayor float y pasa a inf (con NumPy, además, avisa)."""
        try:
            import numpy
            valor = numpy.float64(sys.float_info.max) * numpy.float64(10)
            ejemplo = "numpy.float64(1.7976931348623157e308) * 10"
        except ImportError:
            valor, ejemplo = sys.float_info.max * 10, "1.7976931348623157e308 * 10"
        return {"tipo": "Overflow", "ejemplo": ejemplo, "resultado": repr(float(valor)),
                "explicacion": "El valor supera el mayor float representable (≈ 1.8e308) y se redondea a inf."}

    @staticmethod
    def _potencia():
        """Overflow que en Python lanza una excepción en lugar de devolver inf."""
        try:
            resultado = repr(2.0 ** 1024)
        except OverflowError as error:
            resultado = f"OverflowError: {error}"
        return {"tipo": "Overflow", "ejemplo": "2.0 ** 1024", "resultado": resultado,
                "explicacion": "Python lanza una excepción en la potencia; con NumPy se obtiene inf con una advertencia."}

    @staticmethod
    def _pequeno():
        """Underflow: un valor menor que el menor subnormal se redondea a 0."""
        valor = 5e-324 / 2
        return {"tipo": "Underflow", "ejemplo": "5e-324 / 2", "resultado": repr(valor),
                "explicacion": "5e-324 es el menor float positivo; la mitad ya no se puede representar y queda en 0.0."}

    @staticmethod
    def _gradual():
        """Underflow gradual: valores subnormales con menos dígitos significativos."""
        valor = 1e-310 * 1e-10
        return {"tipo": "Underflow", "ejemplo": "1e-310 * 1e-10", "resultado": repr(valor),
                "explicacion": "1e-310 ya es subnormal (pierde precisión); al reducirlo más se llega a 0.0. "
                               "El comportamiento exacto puede variar según el equipo y la operación."}


class TiposDeError:
    """Definición y ejemplo calculado de cada tipo de error pedido en el enunciado."""

    @staticmethod
    def lista():
        """Devuelve los seis tipos de error como EjemploError."""
        redondeo = abs(math.sqrt(2) - 1.4142)
        truncamiento = abs(math.e - (1 + 1 + 1 / 2 + 1 / 6))
        return [
            EjemploError("Error inherente", "Viene de los datos de entrada: mediciones o valores que ya traen incertidumbre.",
                         "Medir 12.3 cm con una regla de 1 mm: el dato verdadero puede estar entre 12.25 y 12.35."),
            EjemploError("Error de redondeo", "Se produce al representar un número con un número finito de cifras.",
                         f"√2 ≈ 1.4142 en lugar de 1.41421356…: error = {redondeo:.3e}."),
            EjemploError("Error de truncamiento", "Se produce al cortar un proceso infinito, como una serie o un método iterativo.",
                         f"e ≈ 1 + 1 + 1/2 + 1/6 (se cortan los demás términos): error = {truncamiento:.4f}."),
            EjemploError("Overflow", "El resultado es mayor que el mayor número representable.",
                         "1.8e308 * 10 da inf en doble precisión."),
            EjemploError("Underflow", "El resultado es menor que el menor número representable distinto de cero.",
                         "5e-324 / 2 da 0.0."),
            EjemploError("Error del modelo matemático", "El modelo no describe bien el fenómeno real, aunque se calcule exacto.",
                         "Caída libre sin resistencia del aire: v = g·t sigue creciendo, pero un cuerpo real alcanza una "
                         "velocidad límite. El error de truncamiento es del método; el de modelación es del modelo."),
        ]


class CalculoErrores:
    """Errores absoluto, relativo y relativo porcentual entre un valor verdadero y uno aproximado."""

    @staticmethod
    def calcular(verdadero, aproximado):
        """Devuelve (Ea, Er, Er%); Er y Er% son None si el valor verdadero es 0 (no definido)."""
        if not (math.isfinite(verdadero) and math.isfinite(aproximado)):
            raise ErrorNumerico("Los valores deben ser números finitos")
        absoluto = abs(verdadero - aproximado)
        if verdadero == 0:
            return absoluto, None, None
        relativo = absoluto / abs(verdadero)
        return absoluto, relativo, relativo * 100


class PropagacionError:
    """Propagación del error para f(x) = sen(x) + x² con f'(x) = cos(x) + 2x."""

    @staticmethod
    def f(x):
        """f(x) = sen(x) + x²."""
        return math.sin(x) + x ** 2

    @staticmethod
    def derivada(x):
        """f'(x) = cos(x) + 2x."""
        return math.cos(x) + 2 * x

    @classmethod
    def calcular(cls, x, delta_x):
        """Compara Δy aproximado (f'(x)·Δx) con Δy real (f(x + Δx) − f(x))."""
        if not (math.isfinite(x) and math.isfinite(delta_x)):
            raise ErrorNumerico("x y Δx deben ser números finitos")
        aproximado = cls.derivada(x) * delta_x
        real = cls.f(x + delta_x) - cls.f(x)
        return {"fx": cls.f(x), "derivada": cls.derivada(x), "aproximado": aproximado, "real": real,
                "diferencia": abs(aproximado - real)}
