"""Módulo A: método de Bisección programado desde cero (SciPy solo contrasta el resultado).
Valida el intervalo, comprueba el cambio de signo (Bolzano), itera con xr = (a + b)/2 y la
cota Eb = (b − a)/2, y registra cada iteración. No usa input() ni print().
Elaborado por: [Integrantes del grupo: completar nombres].
"""
import math
from dataclasses import dataclass, field

from .evaluador_seguro import ErrorNumerico, formato


@dataclass
class Iteracion:
    """Valores usados para calcular xr (antes de actualizar el intervalo) y sus errores."""
    k: int
    a: float
    b: float
    xr: float
    fa: float
    fb: float
    fr: float
    cota_eb: float
    error_aprox: object = None  # |xr_k − xr_(k−1)|; None en la primera iteración
    error_relativo: object = None  # εa; None en la primera iteración o "No definido" si xr = 0


@dataclass
class ResultadoBiseccion:
    """Resumen del método: cómo terminó, la raíz aproximada, la tabla y las advertencias."""
    estado: str  # extremo_exacto | sin_cambio_signo | discontinuidad | raiz_exacta | tolerancia | max_iteraciones
    mensaje: str
    n_teorico: int
    iteraciones: list = field(default_factory=list)
    raiz: object = None
    f_raiz: object = None
    cota_error: object = None
    advertencias: list = field(default_factory=list)

    @property
    def encontro_raiz(self):
        """True si el método terminó con una raíz o aproximación utilizable."""
        return self.estado in ("extremo_exacto", "raiz_exacta", "tolerancia", "max_iteraciones")

    @property
    def es_confiable(self):
        """True si no hay advertencias de discontinuidad y se puede contrastar con SciPy."""
        return self.encontro_raiz and not self.advertencias


class Biseccion:
    """Método de Bisección sobre una función f ya validada (FuncionSegura o cualquier callable)."""

    PUNTOS_EXPLORACION = 1000

    def __init__(self, funcion, a, b, tolerancia, maximo_iteraciones):
        """Valida los datos de entrada y guarda el problema."""
        self._validar(a, b, tolerancia, maximo_iteraciones)
        self.f, self.a0, self.b0 = funcion, float(a), float(b)
        self.tolerancia, self.maximo = float(tolerancia), int(maximo_iteraciones)

    @staticmethod
    def _validar(a, b, tolerancia, maximo):
        """Rechaza límites incorrectos, tolerancia no positiva y máximo menor que 1."""
        if not all(math.isfinite(v) for v in (a, b, tolerancia)):
            raise ErrorNumerico("Los límites y la tolerancia deben ser números finitos")
        if a >= b:
            raise ErrorNumerico(f"El extremo inferior a ({a:g}) debe ser menor que b ({b:g})")
        if tolerancia <= 0:
            raise ErrorNumerico("La tolerancia E debe ser positiva (E > 0)")
        if maximo != int(maximo) or maximo < 1:
            raise ErrorNumerico("Las iteraciones máximas deben ser un entero mayor o igual que 1")

    @staticmethod
    def iteraciones_teoricas(a, b, tolerancia):
        """n mínimo = ⌈log2((b − a)/E)⌉, de la cota |r − xr_n| ≤ (b − a)/2ⁿ (al menos 1)."""
        return max(1, math.ceil(math.log2((b - a) / tolerancia)))

    def _evaluar_extremo(self, x, nombre):
        """f en un extremo; si no está definida se explica cuál extremo falla."""
        try:
            return self.f(x)
        except ErrorNumerico as error:
            raise ErrorNumerico(f"No se puede evaluar f({nombre}): {error}") from None

    def _puntos_no_definidos(self):
        """Primer punto del intervalo donde f no está definida (None si f se evalúa en todos)."""
        paso = (self.b0 - self.a0) / self.PUNTOS_EXPLORACION
        for i in range(1, self.PUNTOS_EXPLORACION):
            try:
                self.f(self.a0 + i * paso)
            except ErrorNumerico:
                return self.a0 + i * paso
        return None

    def resolver(self):
        """Ejecuta el método completo y devuelve un ResultadoBiseccion."""
        n_teorico = self.iteraciones_teoricas(self.a0, self.b0, self.tolerancia)
        fa, fb = self._evaluar_extremo(self.a0, "a"), self._evaluar_extremo(self.b0, "b")
        for extremo, valor in ((self.a0, fa), (self.b0, fb)):
            if valor == 0:
                return ResultadoBiseccion("extremo_exacto", f"x = {extremo:g} es una raíz exacta en un extremo del intervalo",
                                          n_teorico, raiz=extremo, f_raiz=0.0, cota_error=0.0)
        if (fa > 0) == (fb > 0):
            return ResultadoBiseccion(
                "sin_cambio_signo", "El intervalo no cumple f(a)·f(b) < 0 (no hay cambio de signo). "
                "Esto no significa que f no tenga raíces en otros intervalos.", n_teorico)
        sospechoso = self._puntos_no_definidos()
        if sospechoso is not None:
            return self._discontinuidad(sospechoso, n_teorico)
        return self._iterar(fa, fb, n_teorico)

    def _discontinuidad(self, x, n_teorico):
        """Resultado cuando f no está definida dentro del intervalo: no se cumplen las condiciones."""
        return ResultadoBiseccion(
            "discontinuidad", f"f no está definida en x ≈ {x:.6g} dentro de [{self.a0:g}, {self.b0:g}]: "
            "f no es continua en el intervalo y no se cumplen las condiciones del método (teorema de Bolzano). "
            "El cambio de signo en los extremos puede deberse a una asíntota, no a una raíz.", n_teorico)

    def _iterar(self, fa, fb, n_teorico):
        """Bucle principal: registra los valores usados antes de actualizar el intervalo."""
        a, b, filas, anterior = self.a0, self.b0, [], None
        for k in range(1, self.maximo + 1):
            xr, eb = (a + b) / 2, (b - a) / 2
            try:
                fr = self.f(xr)
            except ErrorNumerico as error:
                return self._interrumpido(error, filas, n_teorico)
            filas.append(Iteracion(k, a, b, xr, fa, fb, fr, eb, *self._errores_aprox(xr, anterior)))
            anterior = xr
            if fr == 0:
                return self._terminar("raiz_exacta", "f(xr) = 0: raíz exacta en aritmética de máquina", filas, n_teorico)
            if eb <= self.tolerancia:
                return self._terminar("tolerancia", "Se alcanzó la tolerancia: Eb ≤ E", filas, n_teorico)
            if (fa > 0) != (fr > 0):
                b, fb = xr, fr
            else:
                a, fa = xr, fr
        return self._terminar("max_iteraciones", f"Se alcanzó el máximo de {self.maximo} iteraciones sin cumplir la "
                              "tolerancia: la raíz es solo una aproximación, sin garantía del error pedido", filas, n_teorico)

    @staticmethod
    def _errores_aprox(xr, anterior):
        """(Ea, εa): None en la primera iteración y 'No definido' si xr = 0."""
        if anterior is None:
            return None, None
        ea = abs(xr - anterior)
        return ea, ("No definido" if xr == 0 else ea / abs(xr))

    def _interrumpido(self, error, filas, n_teorico):
        """Un punto medio cayó donde f no está definida: se informa y se conserva la tabla parcial."""
        return ResultadoBiseccion("discontinuidad", f"Se interrumpió el método: {error}. La función no es continua en "
                                  "el intervalo y no se cumplen las condiciones del método.", n_teorico, iteraciones=filas)

    def _terminar(self, estado, mensaje, filas, n_teorico):
        """Arma el resultado final y añade las advertencias sobre n teórico y posibles asíntotas."""
        ultima = filas[-1]
        resultado = ResultadoBiseccion(estado, mensaje, n_teorico, filas, ultima.xr, ultima.fr, ultima.cota_eb)
        if estado == "max_iteraciones" and self.maximo < n_teorico:
            resultado.advertencias.append(f"El máximo ({self.maximo}) es menor que el n teórico ({n_teorico}): "
                                          "no se garantiza la tolerancia solicitada.")
        # Una raíz real hace que |f(xr)| tienda a 0; si crece más que en los extremos, hay una asíntota
        if abs(ultima.fr) > max(abs(filas[0].fa), abs(filas[0].fb)):
            resultado.advertencias.append("|f(xr)| es mayor que |f| en los extremos: el cambio de signo parece deberse "
                                          "a una asíntota o discontinuidad, no a una raíz.")
        return resultado


def contrastar_con_scipy(funcion, a, b):
    """Raíz de scipy.optimize.bisect para comparar; (None, motivo) si SciPy no está disponible."""
    try:
        from scipy.optimize import bisect
    except ImportError:
        return None, "SciPy no está instalada (pip install scipy): se omite la comparación externa."
    try:
        return bisect(funcion, a, b, xtol=1e-12), ""
    except (ValueError, RuntimeError, ErrorNumerico) as error:
        return None, f"SciPy no pudo calcular la raíz: {error}"


def fila_a_texto(it):
    """Convierte una Iteracion en una lista de textos para tablas (consola y web)."""
    relativo = it.error_relativo if isinstance(it.error_relativo, str) else formato(it.error_relativo, 6)
    return [str(it.k), formato(it.a), formato(it.b), formato(it.xr), formato(it.fa, 6), formato(it.fb, 6),
            formato(it.fr, 6), formato(it.cota_eb, 6), "—" if relativo is None else relativo]
