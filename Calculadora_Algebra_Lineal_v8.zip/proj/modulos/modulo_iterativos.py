"""Módulo del Programa 8: Jacobi y Gauss-Seidel en la consola.
Pide A, b, x⁽⁰⁾, ε y el máximo de iteraciones, muestra el análisis de la diagonal, las tablas,
el residuo, la comparación y la gráfica del error. Cada dato inválido se vuelve a pedir.
Elaborado por: [Integrantes del grupo: completar nombres].
"""
from fractions import Fraction

from .evaluador_seguro import ErrorNumerico, formato, leer_numero
from .interfaz import Consola, Entrada
from .modulo_matrices import ErrorMatriz, Matriz
from .numerico_iterativos import (CASOS_ITERATIVOS, AnalisisDiagonal, ProblemaIterativo, SistemaIterativo)

LOGO_ITERATIVOS = r"""
      #   #####   ####   ###   ####  ###
      #  #   #   #   # #   # #       #
      #  #####   ####  #   # #       #
  #   #  #   #   #   # #   # #       #
   ###   #   #   ####   ###   ####  ###
  ------  J A C O B I   Y   G A U S S - S E I D E L  ------
"""
FILAS_VISIBLES = 40


class GraficaError:
    """Gráfica comparativa del error por iteración (escala logarítmica) con Matplotlib opcional."""

    @staticmethod
    def dibujar(resultados, guardar_en=None):
        """Dibuja Jacobi y Gauss-Seidel; devuelve '' o el motivo si no se pudo."""
        try:
            import matplotlib
            if guardar_en:
                matplotlib.use("Agg")
            import matplotlib.pyplot as plt
        except ImportError:
            return "Matplotlib no está instalada (pip install matplotlib). La página web también dibuja la gráfica."
        figura, eje = plt.subplots(figsize=(8, 5))
        for resultado in resultados:
            errores = [max(e, 1e-17) for e in resultado.errores]
            eje.semilogy(range(1, len(errores) + 1), errores, marker="o", markersize=3, label=resultado.metodo)
        eje.set(title="Error por iteración: Jacobi y Gauss-Seidel", xlabel="Iteración k",
                ylabel="‖x⁽ᵏ⁾ − x⁽ᵏ⁻¹⁾‖∞ (escala logarítmica)")
        eje.grid(True, alpha=0.4)
        eje.legend()
        if guardar_en:
            figura.savefig(guardar_en, dpi=120)
            plt.close(figura)
        else:
            plt.show()
        return ""


class MenuIterativos:
    """Menú del Programa 8."""

    def __init__(self, asistente):
        """Recibe el AsistenteMemoria para poder usar la Matriz A de la memoria."""
        self.memoria = asistente

    def ejecutar(self):
        """Muestra el menú y resuelve el sistema elegido."""
        Consola.logo(LOGO_ITERATIVOS)
        Consola.encabezado("JACOBI Y GAUSS-SEIDEL")
        Consola.opcion("1", "Usar la Matriz A de la memoria y escribir b")
        Consola.opcion("2", "Ingresar un sistema nuevo")
        Consola.opcion("3", "Cargar un caso de prueba del programa")
        Consola.opcion("0", "Volver al menú principal")
        opcion = Entrada.opcion("\n  Seleccione una opción: ", ["1", "2", "3", "0"])
        if opcion == "0":
            return
        try:
            preparado = {"1": self._de_memoria, "2": self._nuevo, "3": self._caso}[opcion]()
            self._resolver(*preparado)
        except (ErrorMatriz, ErrorNumerico) as error:
            Consola.error(str(error))
        Consola.pausar()

    # ---------- datos de entrada ----------

    def _de_memoria(self):
        """A viene de la memoria; se piden b, x⁽⁰⁾, ε y el máximo."""
        a = self.memoria.requerir("A")
        Consola.matriz(a.datos, "Matriz de coeficientes (A)")
        return (a, *self._pedir_vectores(a.filas), *self._pedir_parada(), None)

    def _nuevo(self):
        """Pide n, cada fila de A y luego b, x⁽⁰⁾, ε y el máximo."""
        n = Entrada.entero_positivo("  Orden n de la matriz cuadrada A: ", maximo=8)
        Consola.info(f"Escriba cada fila de A con {n} números separados por espacios.")
        a = Matriz([Entrada.fila(f"    Fila {i + 1}: ", n) for i in range(n)])
        return (a, *self._pedir_vectores(n), *self._pedir_parada(), None)

    @staticmethod
    def _pedir_vectores(n):
        """Pide b y x⁽⁰⁾ con n componentes."""
        b = Entrada.fila(f"  Vector b ({n} términos independientes): ", n)
        x0 = Entrada.fila(f"  Vector inicial x⁽⁰⁾ ({n} componentes): ", n)
        return b, x0

    @staticmethod
    def _pedir_parada():
        """Pide ε y el máximo de iteraciones hasta que ambos sean válidos."""
        while True:
            try:
                tolerancia = leer_numero(input("  Tolerancia ε (decimal positivo, ej. 1e-6): "), "ε")
                maximo = Entrada.entero_positivo("  Número máximo de iteraciones: ")
                SistemaIterativo.validar_parada(tolerancia, maximo)
                return tolerancia, maximo
            except ErrorNumerico as error:
                Consola.error(str(error))

    def _caso(self):
        """Carga uno de los casos de prueba definidos en el módulo de cálculo."""
        for i, caso in enumerate(CASOS_ITERATIVOS, 1):
            Consola.opcion(str(i), caso["nombre"])
        caso = CASOS_ITERATIVOS[int(Entrada.opcion("  Caso: ", [str(i) for i in range(1, len(CASOS_ITERATIVOS) + 1)])) - 1]
        Consola.info(caso["objetivo"])
        b = [Fraction(v) for v in caso["b"]]
        return Matriz(caso["A"]), b, caso["x0"], leer_numero(caso["tol"], "ε"), caso["nmax"], caso["reordenar"]

    # ---------- resolución y presentación ----------

    def _resolver(self, a, b, x0, tolerancia, maximo, reordenar):
        """Analiza la diagonal, decide el reordenamiento y muestra los resultados."""
        reordenar = self._decidir_reordenamiento(a, reordenar)
        informe = ProblemaIterativo.ejecutar(a, b, x0, tolerancia, maximo, reordenar)
        self._mostrar_analisis(informe)
        if informe.bloqueo:
            Consola.error(informe.bloqueo + " No se inicia el cálculo.")
            return
        for resultado in informe.resultados:
            self._mostrar_metodo(resultado, informe)
        for linea in informe.comparacion():
            Consola.info(linea)
        if all(r.errores for r in informe.resultados) and Entrada.si_no("  ¿Ver la gráfica del error?"):
            motivo = GraficaError.dibujar(informe.resultados)
            if motivo:
                Consola.aviso(motivo)

    @staticmethod
    def _decidir_reordenamiento(a, preajuste):
        """Pregunta si se aplica el reordenamiento propuesto cuando A no es dominante o tiene ceros."""
        if preajuste is not None:
            return preajuste
        datos = [[float(v) for v in fila] for fila in a.datos]
        propuesta = AnalisisDiagonal.reordenar(datos) if len(datos) <= 8 else None
        if AnalisisDiagonal.es_dominante(datos) and not AnalisisDiagonal.ceros(datos):
            return False
        if propuesta is None or not propuesta.cambia:
            return False
        orden = ", ".join(f"fila {i + 1}" for i in propuesta.permutacion)
        Consola.aviso(f"Un reordenamiento de filas ({orden}) mejora la diagonal.")
        return Entrada.si_no("  ¿Aplicarlo?")

    @staticmethod
    def _mostrar_analisis(informe):
        """Dominancia por filas, ceros en la diagonal y resultado del reordenamiento."""
        Consola.seccion("Análisis de la diagonal")
        if informe.aplicado:
            Consola.info("Se aplicó el reordenamiento de filas (A y b se reordenan juntos; la solución no cambia).")
        Consola.matriz([[formato(v) for v in fila] for fila in informe.a_usada], "Matriz A usada")
        for f in informe.filas_dominancia:
            marca = "✔" if f.estricta else "✘"
            print(f"  {marca} Fila {f.fila}: |a_ii| = {f.diagonal:g}  {'>' if f.estricta else '≤'}  Σ|a_ij| = {f.resto:g}")
        (Consola.exito if informe.dominante else Consola.aviso)(
            "A es estrictamente diagonal dominante por filas (condición suficiente de convergencia)."
            if informe.dominante else
            "A no es estrictamente diagonal dominante. Esto NO implica divergencia: la condición es suficiente, no necesaria.")
        if informe.reordenamiento is None and informe.ceros:
            Consola.error("No existe ninguna permutación de filas que deje la diagonal sin ceros; no se fuerza un reordenamiento.")

    def _mostrar_metodo(self, resultado, informe):
        """Tabla de iteraciones, estado, solución, residuo y diferencia con la referencia."""
        Consola.seccion(resultado.metodo)
        n = len(resultado.solucion)
        print("  " + f"{'k':>4}" + "".join(f"{'x' + str(i + 1):>14}" for i in range(n)) + f"{'error':>14}{'residuo':>14}")
        visibles = self._filas_visibles(resultado.iteraciones)
        for it in visibles:
            if it is None:
                print("  ...")
                continue
            print("  " + f"{it.k:>4}" + "".join(f"{formato(v, 8):>14}" for v in it.x)
                  + f"{formato(it.error, 5):>14}{formato(it.residuo, 5):>14}")
        (Consola.exito if resultado.converge else Consola.error)(resultado.mensaje)
        for aviso in resultado.advertencias:
            Consola.aviso(aviso)
        print("  Solución aproximada: [" + ", ".join(formato(v, 8) for v in resultado.solucion) + "]")
        print(f"  Iteraciones: {len(resultado.iteraciones)}   Residuo final ‖Ax − b‖∞ = {formato(resultado.residuo, 5)}")
        diferencia = informe.diferencia_con_referencia(resultado)
        if diferencia is not None:
            print(f"  Diferencia con la referencia ({informe.nota_referencia}): {diferencia:.3e}")

    @staticmethod
    def _filas_visibles(iteraciones):
        """Todas las filas si son pocas; si no, las primeras 25, '...' y las últimas 10."""
        if len(iteraciones) <= FILAS_VISIBLES:
            return iteraciones
        return iteraciones[:25] + [None] + iteraciones[-10:]
